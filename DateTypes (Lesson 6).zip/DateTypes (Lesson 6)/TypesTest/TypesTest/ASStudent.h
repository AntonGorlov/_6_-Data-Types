//
//  ASStudent.h
//  TypesTest
//
//  Created by Anton Gorlov on 07.09.15.
//  Copyright (c) 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ASStudent : NSObject
@property (assign, nonatomic) NSString* name;
@property (assign,nonatomic) BOOL isMale;


typedef enum {
    ASGenderMale,
    ASGenderFemale,
    ASGenderMidle,
} ASGender;
@property (assign,nonatomic) ASGender gender;

@end
