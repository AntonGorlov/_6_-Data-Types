//
//  ASFootballPlayer.m
//  TypesTest
//
//  Created by Anton Gorlov on 08.09.15.
//  Copyright (c) 2015 Anton Gorlov. All rights reserved.
//

#import "ASFootballPlayer.h"

@implementation ASFootballPlayer

@end
