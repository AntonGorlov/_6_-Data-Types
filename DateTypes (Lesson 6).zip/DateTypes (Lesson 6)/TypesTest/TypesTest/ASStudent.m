//
//  ASStudent.m
//  TypesTest
//
//  Created by Anton Gorlov on 07.09.15.
//  Copyright (c) 2015 Anton Gorlov. All rights reserved.
//

#import "ASStudent.h"

@implementation ASStudent

@end
