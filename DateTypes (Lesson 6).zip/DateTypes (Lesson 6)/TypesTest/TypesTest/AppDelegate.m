//
//  AppDelegate.m
//  TypesTest
//
//  Created by Anton Gorlov on 04.09.15.
//  Copyright (c) 2015 Anton Gorlov. All rights reserved.
//

#import "AppDelegate.h"
#import "ASStudent.h"
#import "ASFootballPlayer.h"
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    /*
    BOOL boolVar=YES;
    NSInteger intVar =10;
    NSUInteger uIntVar =100;
    CGFloat floatVar =1.5f;
    double doubleVar =2.5f;
     */
   /*
    
    NSLog(@"boolVar=%d,intVar=%d,uIntVar=%d,floatVar=%f,doubleVar=%f",boolVar,intVar,uIntVar,floatVar, doubleVar);
    NSLog(@"boolVar=%ld,intVar=%ld,uIntVar=%ld,floatVar=%ld,doubleVar=%ld",sizeof(boolVar),sizeof(intVar),sizeof(uIntVar),sizeof(floatVar), sizeof(doubleVar));
    */
    /*
    ASStudent* studentA=[[ASStudent alloc] init];
    studentA.name=@"Best student";
    NSLog(@"%@", studentA.name);
    
    ASStudent*studentB=studentA;
    studentB.name=@"Bad student";
    NSLog(@"StudentA=%@", studentA.name);
     */
    /*
    NSInteger a=20;
    NSLog(@"a=%ld",a);
    NSInteger b=a;
    b=10;
    NSLog(@"a=%ld,b=%ld",a,b);
    NSInteger*c=&a;
    *c=4;
    NSLog(@"a=%ld,b=%ld",a,b);
     */
    /*
    ASStudent*student=[[ASStudent alloc]init];
    student.isMale=YES;
    */
    
    /*
    ASStudent*student=[[ASStudent alloc]init];
    [student setGender:ASGenderMale];
    */
    /*
    ASFootballPlayer*player =[[ASFootballPlayer alloc]init];
    [player setPlayer:ASFootballPlayerDefender];
    [player setPlayer:ASFootballPlayerForward];
    [player setPlayer:ASFootballPlayerGoalkeeper];
    [player setPlayer:ASFootballPlayerHaldback];
    */
    /*
    CGPoint point;
    point.x=4.6f;
    point.y=5;
    NSLog(@"point x=%f",point.x);
    NSLog(@"point y=%f",point.y);
    
    CGSize size;
    size.height=7;
    size.width=3.8f;
    NSLog(@"height=%f,width=%f ",size.height , size.width);
    
    CGRect rect;
    rect.origin=point;
    rect.size=size;
    NSLog(@"point.x=%f,point.y=%f, height=%f,width=%f",point.x,point.y, size.height , size.width);
    */
    /*
    
    CGPoint point;
    point.x=4.6f;
    point.y=5;
    
    point = CGPointMake (6.2,5 );
    NSLog(@"point x=%f, point y=%f", point.x ,point.y);
    
    
    CGSize size;
    size.height=7;
    size.width=3.8f;
    
    CGRect rect;
    rect.origin=point;
    rect.size=size;
    
    rect = CGRectMake(5.2, 6.5, 7, 3.8);
    NSLog(@"point x=%f, point y=%f, height=%f, widht=%f",rect.origin, rect.size);
    
    */
    
    /*
    BOOL boolVar=YES;
    NSInteger intVar =10;
    NSUInteger uIntVar =100;
    CGFloat floatVar =1.5f;
    double doubleVar =2.5f;
    
    
    NSNumber*boolObject=[NSNumber numberWithBool:boolVar];
    NSNumber*intObject=[NSNumber numberWithInteger:intVar];
    NSNumber*uIntObject=[NSNumber numberWithUnsignedInt:uIntVar];
    NSNumber*floatObject=[NSNumber numberWithFloat:floatVar];
    NSNumber*doubleObject=[NSNumber numberWithDouble:doubleVar];
    
    NSArray*array=[NSArray arrayWithObjects:boolObject,intObject,uIntObject,floatObject,doubleObject, nil];
    NSLog(@"boolVar=%d,intVar=%d,uIntVar=%d,floatVar=%f,doubleVar=%f",
          [[array objectAtIndex :0]boolValue],
          [[array objectAtIndex :1]intValue],
          [[array objectAtIndex :2]unsignedIntegerValue],
          [[array objectAtIndex :3]floatValue],
          [[array objectAtIndex :4]doubleValue]);
     */
    
    CGPoint point1=CGPointMake(2, 3);
    CGPoint point2=CGPointMake(5, 8);
    CGPoint point3=CGPointMake(1, 4);
    CGPoint point4=CGPointMake(7, 7);
    CGPoint point5=CGPointMake(2, 10);
    
    NSArray* array2= [NSArray arrayWithObjects:
    [NSValue valueWithCGPoint:point1],
    [NSValue valueWithCGPoint:point2],
    [NSValue valueWithCGPoint:point3],
    [NSValue valueWithCGPoint:point4],
    [NSValue valueWithCGPoint:point5],
    nil];
    
    for  (NSValue* value in array2){
        CGPoint a= [value CGPointValue];
        NSLog(@"point%@",NSStringFromCGPoint(a));
    }
    
    
    
   
   
    
          
    

  

    
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
