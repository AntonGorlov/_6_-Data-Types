//
//  main.m
//  TypesTest
//
//  Created by Anton Gorlov on 04.09.15.
//  Copyright (c) 2015 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
