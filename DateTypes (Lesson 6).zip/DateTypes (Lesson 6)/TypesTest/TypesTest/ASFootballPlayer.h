//
//  ASFootballPlayer.h
//  TypesTest
//
//  Created by Anton Gorlov on 08.09.15.
//  Copyright (c) 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ASFootballPlayer : NSObject

typedef enum {
    ASFootballPlayerGoalkeeper,
    ASFootballPlayerDefender,
    ASFootballPlayerHaldback,
    ASFootballPlayerForward,
} ASFootballPlayers;
   
@property (assign,nonatomic) ASFootballPlayers player;

@end
