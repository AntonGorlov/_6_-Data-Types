//
//  AppDelegate.m
//  HomeWork Lesson 6 (Date Types)
//
//  Created by Anton Gorlov on 26.09.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AppDelegate.h"
#import "AGZidan.h"
#import "AGBaggio.h"
#import "AGRonaldinho.h"


@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    //1. Я очень хочу чтобы вы попрактиковались создавать и использовать enum списки. Они ОЧЕНЬ распространены, они делают код красивее и вносят дополнительную информацию. Это просто очень хорошая практика их использовать! Практикуйтесь! Создайте кучу разных пропертей под разные энумы. Постарайтесь усвоить это сразу.

    
    AGZidan* zidan=[[AGZidan alloc]init];
    zidan.name=@"Zinadine Zidan";
    zidan.nickName=@"Zizu";
    zidan.height=1.85f;
    [zidan setGoalsACareer:750];
    [zidan setStrike:96];
    [zidan setPass:93];
    [zidan setDribbling:98];
    [zidan setSpeed:85];
    [zidan setHeaders:89];
    [zidan setZidanLegs:AGZidanRightLeg];
    NSLog(@"%@",zidan);
    
    if (zidan.zidanLegs== (AGZidanLeftLeg)) {
        NSLog(@"%@  - leftleg", zidan.name);
    }
        else
             {
            NSLog(@"%@  - rightleg", zidan.name);
                 NSLog(@"--------------");
        }
    
    
    AGBaggio* baggio=[[AGBaggio alloc]init];
    baggio.name=@"Roberto Baggio";
    baggio.nickName=@"Bodge";
    [baggio setHeight:1.80f];
    [baggio setGoalsACareer:820];
    [baggio setStrike:88];
    [baggio setPass:90];
    [baggio setDribbling:92];
    [baggio setSpeed:84];
    [baggio setHeaders:81];
    baggio.baggioLegs=AGBaggioLeftLeg;
    
    NSLog(@"%@",baggio);
    if (baggio.baggioLegs==(AGBaggioRightLeg)) {
        NSLog(@"%@ - rightleg",baggio.name);
    }
   if (baggio.baggioLegs==(AGBaggioLeftLeg)){
        NSLog(@"%@- leftleg",baggio.name);
       NSLog(@"--------------");
    }
  
    AGRonaldinho*ronaldinho=[[AGRonaldinho alloc]init];
    ronaldinho.name=@"Ronaldinho De Ases Moreara";
    ronaldinho.nickName=@"Zubastick";
    ronaldinho.goalsACareer=782;
    ronaldinho.strike=96;
    ronaldinho.pass=98;
    ronaldinho.dribbling=96;
    ronaldinho.speed=93;
    ronaldinho.headers=78;
    ronaldinho.ronaldinhoLegs=AGRonaldinhoRightLeg;
    NSLog(@"%@",ronaldinho);
    
    if ((ronaldinho.ronaldinhoLegs==(AGRonaldinhoRightLeg))) {
        NSLog(@"%@ - right leg",ronaldinho.name);
        NSLog(@"--------------");

    }
    if (ronaldinho.ronaldinhoLegs==(AGRonaldinhoLeftLeg)) {
          NSLog(@"%@- left leg",ronaldinho.name);
    }

    NSArray*bestFootballOnTheWorld=[NSArray arrayWithObjects:zidan,baggio,ronaldinho, nil];
    //count позволяет получать количество елементов в массиве.
    NSLog(@"%lu",(unsigned long)[bestFootballOnTheWorld count]);
    //search in array
    if ([bestFootballOnTheWorld containsObject:@"dsifh"]){ //есть ли этот элемент в массиве.
        NSLog(@"Yes");
    }else {
        NSLog(@"No");
    }
    //сравнение массивов
/* NSArray*bestFootballOnTheWorld1=[NSArray arrayWithObjects:zidan,baggio,ronaldinho, nil];
    if ([bestFootballOnTheWorld isEqualToArray:bestFootballOnTheWorld1]) {
        NSLog(@"Yes");
    }else {
        NSLog(@"No");
    }
*/
    //добавление елемента в массив
/*    NSMutableArray *marray = [[NSMutableArray alloc] init];
    
    for (int i = 0 ; i < 5; i++) {
        [marray addObject:[NSString stringWithFormat:@"element #%d", i]];
    }
 
    [marray insertObject:@"element #Anton" atIndex:3];
    NSLog(@"%@", marray);
*/

    
    //2. Надо попрактиковаться со структурами. Например такое небольшое задание:  на поле 10х10 рандомно создайте точек (разберитесь как рандомно генерировать цифры, подсказка - функция arc4random()) и проверяйте какая из точек попадает в квадрат размером 3х3 в самом центре поля. Грубо говоря надо определить какие из точек в массиве попадают в центр и вывести их на печать. Пробуйте и задавайте вопросы.
    
  /*  CGPoint point1=CGPointMake(3, 3);
    CGPoint point2=CGPointMake(5, 4);
    CGPoint point3=CGPointMake(6, 3);
    CGPoint point4=CGPointMake(6, 6);
    CGPoint point5=CGPointMake(4, 4);
    CGPoint point6=CGPointMake(1, 8);
    [NSValue valueWithCGPoint:point1];
    [NSValue valueWithCGPoint:point2];
    [NSValue valueWithCGPoint:point3];
    [NSValue valueWithCGPoint:point4];
    [NSValue valueWithCGPoint:point5];
    [NSValue valueWithCGPoint:point6];
    
    NSArray* pointArray=[NSArray arrayWithObjects:
                        [NSValue valueWithCGPoint:point1],
                        [NSValue valueWithCGPoint:point2],
                        [NSValue valueWithCGPoint:point3],
                        [NSValue valueWithCGPoint:point4],
                        [NSValue valueWithCGPoint:point5],
                        [NSValue valueWithCGPoint:point6],
                        nil];
 */
    NSInteger x=0;
    NSInteger y=0;
    NSInteger count=0;
    CGPoint point=CGPointMake(0, 0);
    CGRect panzer=CGRectMake(3, 3, 3, 3);//создаем квадрат с координатами танка
    CGRect pointMiss1=CGRectMake(0, 2, 9, 2);// создаем координаты для промаха (не все кооринаты)
   //Так и не понял зачем булевое значение ,но без него не работает!
    bool target =NO;
    bool noTarget=YES;
    
    NSLog(@"Panzer is %ld",panzer);
    /* arc4random() возвращает случайное число в максимальном диапазоне, то есть там могут мыть и единицы, могут быть и тысячи, а могут быть и миллиарды. Чтобы сгенерировать число в нужном диапазоне, скажем от нуля до дясяти, нужно результат от arc4random() разделить на 11 и взять остаток. Оператор % это остаток от деления двух целых чисел.
         Например:
         100 / 3 = 33; 100 % 3 = 1;
         100 / 5 = 20; 100 % 5 = 0;
         100 / 7 = 14; 100 % 7 = 2;
         100 / 11 = 9; 100 % 11 = 1;
         
         то есть чтобы сгенерировать число от 0 до 10 нужно от любого случайного числа (даже 0) взять остаток от деления на 11;
         
         Теперь если тебе надо сгенерировать число от 13 до 20, делается это просто, генерируем число от нуля до 7 (х % 8) и добавляем 13 :)
         
         Для прямоугольника надо сгеренировать 2 координаты и попасть в него и по вертикали и по горизонтали, ну решение сюда давать не буду, чтобы вы сами постарались.
*/
    for (NSInteger i=0;i<=5; i++) {
        x = arc4random() % 11; // Оператор % это остаток от деления двух целых чисел.
        y = arc4random() % 11;
        point=CGPointMake(x, y); //соз точек в (x, y)
        target=CGRectContainsPoint(panzer, point); //в каком-то прямоугольнике какой-то point, то результат вернет - находиться ли данный point в прямоугольнке.
        noTarget=CGRectContainsPoint(pointMiss1, point); // проверка и возвращение промахов в прямоугольнике.
        
        if (target){
            NSLog(@"%ld. You are hit %@!!!!", ++count,NSStringFromCGPoint(point));//достаем pointы и распечатываем
        }
        else NSLog(@"%ld, You are missing %@",++count,NSStringFromCGPoint(point) );
           }
    
    
    

    
    
    
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
