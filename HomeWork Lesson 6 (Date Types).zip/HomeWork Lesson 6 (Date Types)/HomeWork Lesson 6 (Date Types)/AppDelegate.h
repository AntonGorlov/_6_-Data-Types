//
//  AppDelegate.h
//  HomeWork Lesson 6 (Date Types)
//
//  Created by Anton Gorlov on 26.09.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;




@end

