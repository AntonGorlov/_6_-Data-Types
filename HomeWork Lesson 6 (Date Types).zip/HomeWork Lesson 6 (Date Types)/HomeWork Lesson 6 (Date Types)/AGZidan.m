//
//  AGZidan.m
//  HomeWork Lesson 6 (Date Types)
//
//  Created by Anton Gorlov on 26.09.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGZidan.h"

@implementation AGZidan



- (NSString *) description {
    return [NSString stringWithFormat:@"firstName = %@, goals = %ld", self.name, self.goalsACareer];
}

@end
