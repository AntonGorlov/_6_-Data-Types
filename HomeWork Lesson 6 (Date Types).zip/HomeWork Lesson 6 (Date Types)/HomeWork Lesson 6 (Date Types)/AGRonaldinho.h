//
//  AGRonaldinho.h
//  HomeWork Lesson 6 (Date Types)
//
//  Created by Anton Gorlov on 26.09.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGRonaldinho : NSObject
@property (strong, nonatomic) NSString* name;
@property (assign,nonatomic)  NSString* nickName;
@property (assign, nonatomic) float height;
@property (assign,nonatomic)  NSInteger goalsACareer;
@property (assign,nonatomic)  float strike;
@property (assign,nonatomic)  float pass;
@property (assign,nonatomic)  float dribbling;
@property (assign,nonatomic)  float speed;
@property (assign,nonatomic)  float headers;

typedef enum {
    AGRonaldinhoLeftLeg,
    AGRonaldinhoRightLeg
} AGRonaldinhoLeg;
@property (assign,nonatomic) AGRonaldinhoLeg ronaldinhoLegs;

@end
